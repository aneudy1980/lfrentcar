import { ChevronDown } from 'lucide-react'
import { SectionHeading } from '@/components/section-heading'

const faqs = [
  {
    q: '¿Qué necesito para rentar un vehículo?',
    a: 'Licencia de conducir vigente (dominicana o internacional), pasaporte o cédula, y una tarjeta de crédito para el depósito de garantía. La edad mínima es de 21 años.',
  },
  {
    q: '¿Cuánto es el depósito de garantía?',
    a: 'El depósito varía según la categoría del vehículo y se reembolsa al devolverlo en las mismas condiciones. Te lo confirmamos al cotizar.',
  },
  {
    q: '¿Puedo recoger el carro en el aeropuerto?',
    a: 'Sí. Entregamos en los aeropuertos Las Américas (SDQ), Punta Cana (PUJ) y del Cibao (STI). Nuestro agente te espera a la salida con tu nombre.',
  },
  {
    q: '¿Puedo agregar un conductor adicional?',
    a: 'Sí, puedes agregar conductores adicionales presentando su licencia al momento de la entrega.',
  },
  {
    q: '¿Qué pasa si mi vuelo se retrasa?',
    a: 'Monitoreamos tu vuelo. Si se retrasa, ajustamos la hora de entrega sin costo adicional.',
  },
]

export function Faq() {
  return (
    <section id="preguntas" className="scroll-mt-16 bg-muted py-20">
      <div className="mx-auto max-w-3xl px-4">
        <SectionHeading eyebrow="Preguntas frecuentes" title="Todo lo que necesitas saber" />
        <div className="mt-10 flex flex-col gap-3">
          {faqs.map((item) => (
            <details key={item.q} className="group rounded-xl border border-border bg-card px-5 [&_summary::-webkit-details-marker]:hidden">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 py-4 font-semibold text-primary">
                {item.q}
                <ChevronDown className="size-5 shrink-0 transition-transform group-open:rotate-180" aria-hidden="true" />
              </summary>
              <p className="pb-5 leading-relaxed text-muted-foreground">{item.a}</p>
            </details>
          ))}
        </div>
      </div>
    </section>
  )
}
