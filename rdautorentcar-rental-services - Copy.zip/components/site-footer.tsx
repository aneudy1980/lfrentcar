import { Car } from 'lucide-react'
import { site } from '@/lib/site'

export function SiteFooter() {
  return (
    <footer className="bg-primary py-10 text-primary-foreground">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 px-4 text-center md:flex-row md:text-left">
        <div className="flex items-center gap-2 font-bold">
          <span className="flex size-8 items-center justify-center rounded-lg bg-accent text-accent-foreground">
            <Car className="size-4" aria-hidden="true" />
          </span>
          {site.name}
        </div>
        <p className="text-sm text-primary-foreground/70">
          {'© '}
          {new Date().getFullYear()} {site.name}. {site.tagline}.
        </p>
      </div>
    </footer>
  )
}
