'use client'

import { useState, type FormEvent } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { Car, Loader2 } from 'lucide-react'
import { authClient } from '@/lib/auth-client'

type Mode = 'sign-in' | 'sign-up'

const copy = {
  'sign-in': {
    title: 'Iniciar sesión',
    subtitle: 'Accede a tu cuenta para gestionar tus reservas.',
    submit: 'Entrar',
    switchText: '¿No tienes cuenta?',
    switchLabel: 'Crear cuenta',
    switchHref: '/sign-up',
  },
  'sign-up': {
    title: 'Crear cuenta',
    subtitle: 'Regístrate para reservar más rápido y ver tu historial.',
    submit: 'Registrarme',
    switchText: '¿Ya tienes cuenta?',
    switchLabel: 'Iniciar sesión',
    switchHref: '/sign-in',
  },
} as const

const inputClass =
  'h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none transition-shadow focus-visible:ring-2 focus-visible:ring-ring'

export function AuthForm({ mode }: { mode: Mode }) {
  const router = useRouter()
  const [error, setError] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const t = copy[mode]

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError(null)
    setLoading(true)
    const form = new FormData(e.currentTarget)
    const email = String(form.get('email') ?? '').trim()
    const password = String(form.get('password') ?? '')

    const { error } =
      mode === 'sign-up'
        ? await authClient.signUp.email({
            email,
            password,
            name: String(form.get('name') ?? '').trim(),
          })
        : await authClient.signIn.email({ email, password })

    setLoading(false)
    if (error) {
      setError(
        mode === 'sign-up'
          ? 'No pudimos crear tu cuenta. Revisa los datos e inténtalo de nuevo.'
          : 'Correo o contraseña incorrectos.',
      )
      return
    }
    router.push('/cuenta')
    router.refresh()
  }

  return (
    <main className="flex min-h-svh items-center justify-center bg-secondary px-4 py-12">
      <div className="w-full max-w-md">
        <Link href="/" className="mb-8 flex items-center justify-center gap-2 font-bold text-primary">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Car className="size-5" aria-hidden="true" />
          </span>
          <span className="text-lg tracking-tight">RD Auto Rent Car</span>
        </Link>

        <div className="rounded-2xl border border-border bg-card p-6 shadow-sm sm:p-8">
          <h1 className="text-2xl font-bold text-card-foreground text-balance">{t.title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">{t.subtitle}</p>

          <form onSubmit={onSubmit} className="mt-6 flex flex-col gap-4">
            {mode === 'sign-up' && (
              <div className="flex flex-col gap-1.5">
                <label htmlFor="name" className="text-sm font-medium">
                  Nombre completo
                </label>
                <input id="name" name="name" required autoComplete="name" className={inputClass} />
              </div>
            )}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="email" className="text-sm font-medium">
                Correo electrónico
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                autoComplete="email"
                className={inputClass}
              />
            </div>
            <div className="flex flex-col gap-1.5">
              <label htmlFor="password" className="text-sm font-medium">
                Contraseña
              </label>
              <input
                id="password"
                name="password"
                type="password"
                required
                minLength={8}
                autoComplete={mode === 'sign-up' ? 'new-password' : 'current-password'}
                className={inputClass}
              />
              {mode === 'sign-up' && (
                <p className="text-xs text-muted-foreground">Mínimo 8 caracteres.</p>
              )}
            </div>

            {error && (
              <p role="alert" className="rounded-lg bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {error}
              </p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="flex h-11 items-center justify-center gap-2 rounded-lg bg-primary font-semibold text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-60"
            >
              {loading && <Loader2 className="size-4 animate-spin" aria-hidden="true" />}
              {t.submit}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-muted-foreground">
            {t.switchText}{' '}
            <Link href={t.switchHref} className="font-semibold text-primary hover:underline">
              {t.switchLabel}
            </Link>
          </p>
        </div>
      </div>
    </main>
  )
}
