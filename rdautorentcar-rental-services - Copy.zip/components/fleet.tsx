import Image from 'next/image'
import { Briefcase, Snowflake, Users, Cog } from 'lucide-react'
import { fleet, whatsappLink } from '@/lib/site'
import { SectionHeading } from '@/components/section-heading'

export function Fleet() {
  return (
    <section id="flota" className="scroll-mt-16 py-20">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeading
          eyebrow="Nuestra flota"
          title="Un vehículo para cada viaje"
          description="Modelos recientes, revisados antes de cada entrega. Precios en dólares por día, con seguro básico incluido."
        />

        <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {fleet.map((v) => (
            <li
              key={v.id}
              className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-shadow hover:shadow-xl hover:shadow-primary/10"
            >
              <div className="relative aspect-[4/3] bg-muted">
                <Image
                  src={v.image}
                  alt={`${v.category}: ${v.name}`}
                  fill
                  sizes="(min-width: 1024px) 25vw, (min-width: 640px) 50vw, 100vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <span className="absolute left-3 top-3 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  {v.category}
                </span>
              </div>
              <div className="flex flex-1 flex-col p-5">
                <h3 className="font-bold">{v.name}</h3>
                <ul className="mt-3 grid grid-cols-2 gap-2 text-sm text-muted-foreground">
                  <li className="flex items-center gap-1.5">
                    <Users className="size-4" aria-hidden="true" />
                    {v.seats} pasajeros
                  </li>
                  <li className="flex items-center gap-1.5">
                    <Briefcase className="size-4" aria-hidden="true" />
                    {v.bags} maletas
                  </li>
                  <li className="flex items-center gap-1.5">
                    <Cog className="size-4" aria-hidden="true" />
                    {v.transmission}
                  </li>
                  {v.ac && (
                    <li className="flex items-center gap-1.5">
                      <Snowflake className="size-4" aria-hidden="true" />
                      A/C
                    </li>
                  )}
                </ul>
                <div className="mt-5 flex items-end justify-between gap-2 border-t border-border pt-4">
                  <p>
                    <span className="block text-xs text-muted-foreground">Desde</span>
                    <span className="text-2xl font-extrabold text-primary">US${v.pricePerDay}</span>
                    <span className="text-sm text-muted-foreground">/día</span>
                  </p>
                  <a
                    href={whatsappLink(`Hola, me interesa rentar el ${v.category} (${v.name}).`)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                  >
                    Reservar
                    <span className="sr-only"> {v.category}</span>
                  </a>
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
