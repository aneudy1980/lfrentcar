import Image from 'next/image'
import { ShieldCheck, Plane, Clock } from 'lucide-react'
import { BookingForm } from '@/components/booking-form'

export function Hero() {
  return (
    <section className="relative isolate overflow-hidden">
      <Image
        src="/images/hero.png"
        alt=""
        fill
        priority
        sizes="100vw"
        className="-z-10 object-cover"
      />
      <div className="absolute inset-0 -z-10 bg-gradient-to-r from-primary/95 via-primary/80 to-primary/30" />

      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-16 md:py-24 lg:grid-cols-[1.1fr_1fr] lg:items-center">
        <div className="text-primary-foreground">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full bg-accent px-3 py-1 text-xs font-semibold uppercase tracking-wider text-accent-foreground">
            República Dominicana
          </p>
          <h1 className="text-balance text-4xl font-extrabold leading-tight tracking-tight md:text-5xl lg:text-6xl">
            Recorre la isla a tu ritmo, con el carro perfecto.
          </h1>
          <p className="mt-5 max-w-xl text-pretty text-lg leading-relaxed text-primary-foreground/85">
            Renta autos, SUVs, camionetas 4x4 y minivans con entrega en el aeropuerto, tu hotel o tu casa.
            Precios claros, seguro incluido y atención en español e inglés.
          </p>

          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-3 text-sm font-medium">
            <li className="flex items-center gap-2">
              <ShieldCheck className="size-5 text-accent" aria-hidden="true" />
              Seguro incluido
            </li>
            <li className="flex items-center gap-2">
              <Plane className="size-5 text-accent" aria-hidden="true" />
              Entrega en SDQ, PUJ y STI
            </li>
            <li className="flex items-center gap-2">
              <Clock className="size-5 text-accent" aria-hidden="true" />
              Asistencia 24/7
            </li>
          </ul>
        </div>

        <BookingForm />
      </div>
    </section>
  )
}
