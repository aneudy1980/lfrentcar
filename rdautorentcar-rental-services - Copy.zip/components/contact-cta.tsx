import { Mail, MapPin, MessageCircle, Phone, Clock } from 'lucide-react'
import { site, whatsappLink } from '@/lib/site'

export function ContactCta() {
  return (
    <section id="contacto" className="scroll-mt-16 py-20">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 lg:grid-cols-2">
        <div className="rounded-2xl bg-accent p-8 text-accent-foreground md:p-10">
          <h2 className="text-balance text-3xl font-extrabold tracking-tight md:text-4xl">
            ¿Listo para tu próxima aventura?
          </h2>
          <p className="mt-4 max-w-md text-pretty leading-relaxed text-accent-foreground/80">
            Escríbenos y te ayudamos a elegir el vehículo ideal para tu viaje por República Dominicana.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href={whatsappLink('Hola, quiero información sobre la renta de vehículos.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-3 font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              <MessageCircle className="size-5" aria-hidden="true" />
              Escribir por WhatsApp
            </a>
            <a
              href={site.phoneHref}
              className="inline-flex items-center gap-2 rounded-lg border-2 border-primary px-5 py-3 font-semibold text-primary transition-colors hover:bg-primary hover:text-primary-foreground"
            >
              <Phone className="size-5" aria-hidden="true" />
              Llamar ahora
            </a>
          </div>
        </div>

        <address className="flex flex-col justify-center gap-6 rounded-2xl border border-border bg-card p-8 not-italic md:p-10">
          <h3 className="text-xl font-bold text-primary">Información de contacto</h3>
          <ContactRow icon={Phone} label="Teléfono">
            <a href={site.phoneHref} className="hover:underline">
              {site.phoneDisplay}
            </a>
          </ContactRow>
          <ContactRow icon={Mail} label="Correo">
            <a href={`mailto:${site.email}`} className="hover:underline">
              {site.email}
            </a>
          </ContactRow>
          <ContactRow icon={MapPin} label="Oficina">
            {site.address}
          </ContactRow>
          <ContactRow icon={Clock} label="Horario">
            {site.hours}
          </ContactRow>
        </address>
      </div>
    </section>
  )
}

function ContactRow({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ComponentType<{ className?: string; 'aria-hidden'?: boolean }>
  label: string
  children: React.ReactNode
}) {
  return (
    <div className="flex gap-4">
      <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-muted text-primary">
        <Icon className="size-5" aria-hidden={true} />
      </span>
      <div>
        <p className="text-sm text-muted-foreground">{label}</p>
        <p className="font-medium">{children}</p>
      </div>
    </div>
  )
}
