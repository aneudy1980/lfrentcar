import { BadgeDollarSign, MapPin, ShieldCheck, Headset, Gauge, CreditCard } from 'lucide-react'
import { SectionHeading } from '@/components/section-heading'

const benefits = [
  {
    icon: BadgeDollarSign,
    title: 'Precios sin sorpresas',
    text: 'El precio que cotizas es el que pagas. Sin cargos ocultos al momento de la entrega.',
  },
  {
    icon: ShieldCheck,
    title: 'Seguro incluido',
    text: 'Todas las rentas incluyen seguro básico. Ofrecemos cobertura total opcional.',
  },
  {
    icon: MapPin,
    title: 'Entrega donde estés',
    text: 'Te llevamos el vehículo al aeropuerto, a tu hotel o a la puerta de tu casa.',
  },
  {
    icon: Gauge,
    title: 'Kilometraje ilimitado',
    text: 'Recorre de Punta Cana a Samaná o a Puerto Plata sin preocuparte por los kilómetros.',
  },
  {
    icon: Headset,
    title: 'Asistencia 24/7',
    text: 'Asistencia en carretera y atención por WhatsApp a cualquier hora del día.',
  },
  {
    icon: CreditCard,
    title: 'Pagos flexibles',
    text: 'Aceptamos tarjetas de crédito, débito, transferencias y efectivo.',
  },
]

export function Benefits() {
  return (
    <section id="beneficios" className="scroll-mt-16 bg-primary py-20 text-primary-foreground">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeading
          eyebrow="Por qué elegirnos"
          title="Rentar un carro en RD, fácil y seguro"
          className="[&_h2]:text-primary-foreground [&_p:first-child]:text-accent [&_p:last-child]:text-primary-foreground/75"
          description="Somos una empresa dominicana enfocada en que tu experiencia sea rápida, transparente y confiable."
        />
        <ul className="mt-12 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {benefits.map(({ icon: Icon, title, text }) => (
            <li key={title} className="rounded-2xl border border-primary-foreground/10 bg-primary-foreground/5 p-6">
              <span className="flex size-11 items-center justify-center rounded-lg bg-accent text-accent-foreground">
                <Icon className="size-5" aria-hidden="true" />
              </span>
              <h3 className="mt-4 text-lg font-bold">{title}</h3>
              <p className="mt-2 leading-relaxed text-primary-foreground/75">{text}</p>
            </li>
          ))}
        </ul>
      </div>
    </section>
  )
}
