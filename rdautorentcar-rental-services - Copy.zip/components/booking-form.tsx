'use client'

import { useState, type FormEvent } from 'react'
import { MessageCircle } from 'lucide-react'
import { fleet, locations, whatsappLink } from '@/lib/site'
import { createReservation } from '@/app/actions/reservations'

const fieldClass =
  'h-11 w-full rounded-lg border border-input bg-background px-3 text-sm text-foreground outline-none transition focus-visible:border-ring focus-visible:ring-2 focus-visible:ring-ring/30'

function today() {
  return new Date().toISOString().slice(0, 10)
}

export function BookingForm() {
  const [error, setError] = useState<string | null>(null)
  const [pickupDate, setPickupDate] = useState('')

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    const name = String(data.get('name') ?? '').trim()
    const location = String(data.get('location'))
    const start = String(data.get('start'))
    const end = String(data.get('end'))
    const vehicle = String(data.get('vehicle'))

    if (!name || !start || !end) {
      setError('Completa tu nombre y las fechas de la reserva.')
      return
    }
    if (end <= start) {
      setError('La fecha de devolución debe ser posterior a la de recogida.')
      return
    }
    setError(null)

    const message = [
      'Hola RD Auto Rent Car, quiero reservar un vehículo:',
      `• Nombre: ${name}`,
      `• Lugar de entrega: ${location}`,
      `• Recogida: ${start}`,
      `• Devolución: ${end}`,
      `• Vehículo: ${vehicle}`,
    ].join('\n')

    void createReservation({ name, location, vehicle, start, end }).catch(() => {})
    window.open(whatsappLink(message), '_blank', 'noopener,noreferrer')
  }

  return (
    <form
      onSubmit={handleSubmit}
      noValidate
      className="rounded-2xl bg-card p-6 text-card-foreground shadow-2xl shadow-primary/30 md:p-8"
      aria-labelledby="booking-title"
    >
      <h2 id="booking-title" className="text-xl font-bold">
        Cotiza tu reserva
      </h2>
      <p className="mt-1 text-sm text-muted-foreground">Te respondemos por WhatsApp en minutos.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label htmlFor="name" className="text-sm font-medium">
            Nombre completo
          </label>
          <input id="name" name="name" required autoComplete="name" className={fieldClass} placeholder="Ej. María Pérez" />
        </div>

        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label htmlFor="location" className="text-sm font-medium">
            Lugar de entrega
          </label>
          <select id="location" name="location" className={fieldClass} defaultValue={locations[0]}>
            {locations.map((l) => (
              <option key={l}>{l}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="start" className="text-sm font-medium">
            Fecha de recogida
          </label>
          <input
            id="start"
            name="start"
            type="date"
            required
            min={today()}
            value={pickupDate}
            onChange={(e) => setPickupDate(e.target.value)}
            className={fieldClass}
          />
        </div>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="end" className="text-sm font-medium">
            Fecha de devolución
          </label>
          <input id="end" name="end" type="date" required min={pickupDate || today()} className={fieldClass} />
        </div>

        <div className="flex flex-col gap-1.5 sm:col-span-2">
          <label htmlFor="vehicle" className="text-sm font-medium">
            Tipo de vehículo
          </label>
          <select id="vehicle" name="vehicle" className={fieldClass} defaultValue={fleet[0].category}>
            {fleet.map((v) => (
              <option key={v.id} value={v.category}>
                {v.category} – desde US${v.pricePerDay}/día
              </option>
            ))}
          </select>
        </div>
      </div>

      {error && (
        <p role="alert" className="mt-4 text-sm font-medium text-destructive">
          {error}
        </p>
      )}

      <button
        type="submit"
        className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-accent font-semibold text-accent-foreground transition-opacity hover:opacity-90"
      >
        <MessageCircle className="size-5" aria-hidden="true" />
        Reservar por WhatsApp
      </button>
    </form>
  )
}
