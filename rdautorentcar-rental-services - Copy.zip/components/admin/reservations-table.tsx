'use client'

import { useTransition } from 'react'
import { Trash2 } from 'lucide-react'
import { deleteReservation, updateReservationStatus } from '@/app/actions/reservations'
import { STATUSES, statusLabels, type ReservationStatus } from '@/lib/reservation-status'

export type AdminReservation = {
  id: number
  userId: string | null
  name: string
  location: string
  vehicle: string
  startDate: string
  endDate: string
  status: string
  createdAt: string
}

const statusStyles: Record<string, string> = {
  pendiente: 'bg-accent/30 text-foreground',
  confirmada: 'bg-primary/10 text-primary',
  completada: 'bg-secondary text-secondary-foreground',
  cancelada: 'bg-destructive/10 text-destructive',
}

function formatDate(value: string) {
  return new Date(`${value}T00:00:00`).toLocaleDateString('es-DO', { day: '2-digit', month: 'short', year: 'numeric' })
}

function ReservationRow({ r }: { r: AdminReservation }) {
  const [pending, startTransition] = useTransition()

  return (
    <tr className={pending ? 'opacity-50' : undefined}>
      <td className="px-4 py-3 font-medium">
        {r.name}
        <span className="block text-xs font-normal text-muted-foreground">
          {r.userId ? 'Cliente registrado' : 'Invitado'}
        </span>
      </td>
      <td className="px-4 py-3">{r.vehicle}</td>
      <td className="px-4 py-3">{r.location}</td>
      <td className="whitespace-nowrap px-4 py-3">
        {formatDate(r.startDate)} – {formatDate(r.endDate)}
      </td>
      <td className="px-4 py-3">
        <label htmlFor={`status-${r.id}`} className="sr-only">
          Estado de la reserva de {r.name}
        </label>
        <select
          id={`status-${r.id}`}
          value={r.status}
          disabled={pending}
          onChange={(e) =>
            startTransition(() => updateReservationStatus(r.id, e.target.value as ReservationStatus))
          }
          className={`h-9 rounded-full border-0 px-3 text-xs font-semibold outline-none focus-visible:ring-2 focus-visible:ring-ring ${statusStyles[r.status] ?? ''}`}
        >
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {statusLabels[s]}
            </option>
          ))}
        </select>
      </td>
      <td className="px-4 py-3 text-right">
        <button
          type="button"
          disabled={pending}
          onClick={() => {
            if (confirm(`¿Eliminar la reserva de ${r.name}?`)) startTransition(() => deleteReservation(r.id))
          }}
          className="inline-flex size-9 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-destructive/10 hover:text-destructive"
        >
          <Trash2 className="size-4" aria-hidden="true" />
          <span className="sr-only">Eliminar reserva de {r.name}</span>
        </button>
      </td>
    </tr>
  )
}

export function ReservationsTable({ reservations }: { reservations: AdminReservation[] }) {
  if (reservations.length === 0) {
    return (
      <p className="mt-4 rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
        Aún no hay reservas. Las solicitudes enviadas desde el formulario aparecerán aquí.
      </p>
    )
  }

  return (
    <div className="mt-4 overflow-x-auto rounded-2xl border border-border bg-card">
      <table className="w-full min-w-[720px] text-left text-sm">
        <thead className="border-b border-border bg-secondary/50 text-xs uppercase tracking-wide text-muted-foreground">
          <tr>
            <th scope="col" className="px-4 py-3 font-semibold">Cliente</th>
            <th scope="col" className="px-4 py-3 font-semibold">Vehículo</th>
            <th scope="col" className="px-4 py-3 font-semibold">Entrega</th>
            <th scope="col" className="px-4 py-3 font-semibold">Fechas</th>
            <th scope="col" className="px-4 py-3 font-semibold">Estado</th>
            <th scope="col" className="px-4 py-3 font-semibold">
              <span className="sr-only">Acciones</span>
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-border">
          {reservations.map((r) => (
            <ReservationRow key={r.id} r={r} />
          ))}
        </tbody>
      </table>
    </div>
  )
}
