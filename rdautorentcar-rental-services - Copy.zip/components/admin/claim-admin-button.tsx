'use client'

import { useTransition } from 'react'
import { useRouter } from 'next/navigation'
import { ShieldCheck } from 'lucide-react'
import { claimFirstAdmin } from '@/app/actions/reservations'

export function ClaimAdminButton() {
  const [pending, startTransition] = useTransition()
  const router = useRouter()

  return (
    <button
      type="button"
      disabled={pending}
      onClick={() =>
        startTransition(async () => {
          await claimFirstAdmin()
          router.push('/admin')
        })
      }
      className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90 disabled:opacity-60"
    >
      <ShieldCheck className="size-4" aria-hidden="true" />
      {pending ? 'Activando…' : 'Convertirme en administrador'}
    </button>
  )
}
