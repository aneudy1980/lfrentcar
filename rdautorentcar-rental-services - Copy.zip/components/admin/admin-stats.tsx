import type { AdminReservation } from './reservations-table'

export function AdminStats({ reservations }: { reservations: AdminReservation[] }) {
  const count = (status: string) => reservations.filter((r) => r.status === status).length
  const stats = [
    { label: 'Total', value: reservations.length },
    { label: 'Pendientes', value: count('pendiente') },
    { label: 'Confirmadas', value: count('confirmada') },
    { label: 'Completadas', value: count('completada') },
  ]

  return (
    <dl className="mt-8 grid grid-cols-2 gap-4 md:grid-cols-4">
      {stats.map((s) => (
        <div key={s.label} className="rounded-2xl border border-border bg-card p-5">
          <dt className="text-sm text-muted-foreground">{s.label}</dt>
          <dd className="mt-1 text-3xl font-bold text-primary">{s.value}</dd>
        </div>
      ))}
    </dl>
  )
}
