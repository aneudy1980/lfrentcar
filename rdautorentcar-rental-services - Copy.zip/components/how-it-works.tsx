import { SectionHeading } from '@/components/section-heading'

const steps = [
  {
    title: 'Elige tu vehículo',
    text: 'Selecciona la categoría, las fechas y el lugar de entrega en nuestro formulario.',
  },
  {
    title: 'Confirma por WhatsApp',
    text: 'Te enviamos la cotización final y confirmamos la disponibilidad en minutos.',
  },
  {
    title: 'Recibe y maneja',
    text: 'Presenta tu licencia y tarjeta al recibir el vehículo, ¡y a disfrutar del viaje!',
  },
]

export function HowItWorks() {
  return (
    <section id="como-funciona" className="scroll-mt-16 py-20">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeading eyebrow="Cómo funciona" title="Reserva en 3 pasos" />
        <ol className="mt-12 grid gap-8 md:grid-cols-3">
          {steps.map((step, i) => (
            <li key={step.title} className="relative rounded-2xl border border-border bg-card p-6">
              <span className="text-5xl font-extrabold text-accent" aria-hidden="true">
                {String(i + 1).padStart(2, '0')}
              </span>
              <h3 className="mt-3 text-lg font-bold text-primary">{step.title}</h3>
              <p className="mt-2 leading-relaxed text-muted-foreground">{step.text}</p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
