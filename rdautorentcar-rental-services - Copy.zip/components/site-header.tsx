'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Car, Menu, Phone, ShieldCheck, UserRound, X } from 'lucide-react'
import { site } from '@/lib/site'
import { useSession } from '@/lib/auth-client'

const nav = [
  { href: '#flota', label: 'Flota' },
  { href: '#beneficios', label: 'Beneficios' },
  { href: '#como-funciona', label: 'Cómo funciona' },
  { href: '#preguntas', label: 'Preguntas' },
  { href: '#contacto', label: 'Contacto' },
]

export function SiteHeader() {
  const [open, setOpen] = useState(false)
  const { data: session } = useSession()
  const isAdmin = (session?.user as { role?: string } | undefined)?.role === 'admin'

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2 font-bold text-primary">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Car className="size-5" aria-hidden="true" />
          </span>
          <span className="text-lg tracking-tight">
            RD Auto <span className="text-accent-foreground/70">Rent Car</span>
          </span>
        </Link>

        <nav aria-label="Principal" className="hidden md:block">
          <ul className="flex items-center gap-6 text-sm font-medium">
            {nav.map((item) => (
              <li key={item.href}>
                <a href={item.href} className="text-muted-foreground transition-colors hover:text-foreground">
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="flex items-center gap-2">
          {isAdmin && (
            <Link
              href="/admin"
              className="flex items-center gap-2 rounded-lg bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
            >
              <ShieldCheck className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">Admin</span>
              <span className="sr-only sm:hidden">Panel de administración</span>
            </Link>
          )}
          <Link
            href={session?.user ? '/cuenta' : '/sign-in'}
            className="flex items-center gap-2 rounded-lg border border-border px-3 py-2 text-sm font-semibold text-foreground transition-colors hover:bg-secondary"
          >
            <UserRound className="size-4" aria-hidden="true" />
            <span className="hidden sm:inline">{session?.user ? 'Mi cuenta' : 'Iniciar sesión'}</span>
            <span className="sr-only sm:hidden">{session?.user ? 'Mi cuenta' : 'Iniciar sesión'}</span>
          </Link>
          <a
            href={site.phoneHref}
            className="hidden items-center gap-2 rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground transition-opacity hover:opacity-90 sm:flex"
          >
            <Phone className="size-4" aria-hidden="true" />
            {site.phoneDisplay}
          </a>
          <button
            type="button"
            className="flex size-10 items-center justify-center rounded-lg md:hidden"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
          >
            {open ? <X className="size-5" aria-hidden="true" /> : <Menu className="size-5" aria-hidden="true" />}
            <span className="sr-only">{open ? 'Cerrar menú' : 'Abrir menú'}</span>
          </button>
        </div>
      </div>

      {open && (
        <nav id="mobile-nav" aria-label="Móvil" className="border-t border-border md:hidden">
          <ul className="mx-auto flex max-w-6xl flex-col px-4 py-2">
            {nav.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="block py-3 font-medium text-foreground"
                >
                  {item.label}
                </a>
              </li>
            ))}
            <li>
              <a href={site.phoneHref} className="flex items-center gap-2 py-3 font-semibold text-primary">
                <Phone className="size-4" aria-hidden="true" />
                {site.phoneDisplay}
              </a>
            </li>
          </ul>
        </nav>
      )}
    </header>
  )
}
