export const site = {
  name: 'RD Auto Rent Car',
  tagline: 'Renta de vehículos en República Dominicana',
  phoneDisplay: '+1 (347) 567-7596',
  phoneHref: 'tel:+13475677596',
  whatsappNumber: '13475677596',
  email: 'aneudyashley@yahoo.com',
  address: 'Calle Principal, Casa #330, Guayabal, Puñal, Santiago, República Dominicana',
  hours: 'Lunes a domingo, 7:00 a.m. – 10:00 p.m.',
}

export const locations = [
  'Aeropuerto Las Américas (SDQ)',
  'Aeropuerto de Punta Cana (PUJ)',
  'Aeropuerto del Cibao (STI)',
  'Oficina principal – Guayabal, Puñal (Santiago)',
  'Entrega a domicilio / hotel',
]

export type Vehicle = {
  id: string
  name: string
  category: string
  image: string
  pricePerDay: number
  seats: number
  bags: number
  transmission: 'Automática' | 'Manual'
  ac: boolean
}

export const fleet: Vehicle[] = [
  {
    id: 'economico',
    name: 'Kia Rio o similar',
    category: 'Económico',
    image: '/images/car-economy.png',
    pricePerDay: 35,
    seats: 5,
    bags: 2,
    transmission: 'Automática',
    ac: true,
  },
  {
    id: 'suv',
    name: 'Hyundai Tucson o similar',
    category: 'SUV',
    image: '/images/car-suv.png',
    pricePerDay: 65,
    seats: 5,
    bags: 4,
    transmission: 'Automática',
    ac: true,
  },
  {
    id: 'pickup',
    name: 'Toyota Hilux 4x4 o similar',
    category: 'Camioneta 4x4',
    image: '/images/car-pickup.png',
    pricePerDay: 85,
    seats: 5,
    bags: 5,
    transmission: 'Automática',
    ac: true,
  },
  {
    id: 'minivan',
    name: 'Kia Carnival o similar',
    category: 'Minivan',
    image: '/images/car-van.png',
    pricePerDay: 95,
    seats: 7,
    bags: 5,
    transmission: 'Automática',
    ac: true,
  },
]

export function whatsappLink(message: string) {
  return `https://wa.me/${site.whatsappNumber}?text=${encodeURIComponent(message)}`
}
