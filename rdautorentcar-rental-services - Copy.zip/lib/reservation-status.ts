export const STATUSES = ['pendiente', 'confirmada', 'completada', 'cancelada'] as const
export type ReservationStatus = (typeof STATUSES)[number]

export const statusLabels: Record<ReservationStatus, string> = {
  pendiente: 'Pendiente',
  confirmada: 'Confirmada',
  completada: 'Completada',
  cancelada: 'Cancelada',
}
