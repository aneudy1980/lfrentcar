import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import type { Metadata } from 'next'
import { auth } from '@/lib/auth'
import { AuthForm } from '@/components/auth-form'

export const metadata: Metadata = { title: 'Iniciar sesión | RD Auto Rent Car' }

export default async function SignInPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (session?.user) redirect('/cuenta')
  return <AuthForm mode="sign-in" />
}
