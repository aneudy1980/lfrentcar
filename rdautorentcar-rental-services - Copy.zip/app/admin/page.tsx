import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import type { Metadata } from 'next'
import { auth } from '@/lib/auth'
import { SiteHeader } from '@/components/site-header'
import { isCurrentUserAdmin, listReservations } from '@/app/actions/reservations'
import { AdminStats } from '@/components/admin/admin-stats'
import { ReservationsTable } from '@/components/admin/reservations-table'

export const metadata: Metadata = { title: 'Panel de administración | RD Auto Rent Car' }

export default async function AdminPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect('/sign-in')
  if (!(await isCurrentUserAdmin())) redirect('/cuenta')

  const rows = await listReservations()
  const reservations = rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() }))

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-10">
        <h1 className="text-3xl font-bold text-balance">Panel de administración</h1>
        <p className="mt-2 text-muted-foreground">Gestiona las solicitudes de reserva recibidas desde la web.</p>

        <AdminStats reservations={reservations} />

        <section aria-labelledby="reservas" className="mt-8">
          <h2 id="reservas" className="text-lg font-semibold">
            Reservas
          </h2>
          <ReservationsTable reservations={reservations} />
        </section>
      </main>
    </>
  )
}
