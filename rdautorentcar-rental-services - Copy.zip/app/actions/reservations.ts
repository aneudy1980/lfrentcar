'use server'

import { headers } from 'next/headers'
import { revalidatePath } from 'next/cache'
import { desc, eq } from 'drizzle-orm'
import { auth } from '@/lib/auth'
import { db } from '@/lib/db'
import { reservations, user } from '@/lib/db/schema'
import { fleet, locations } from '@/lib/site'
import { STATUSES, type ReservationStatus } from '@/lib/reservation-status'

const DATE_RE = /^\d{4}-\d{2}-\d{2}$/

async function getSessionUser() {
  const session = await auth.api.getSession({ headers: await headers() })
  return session?.user ?? null
}

async function requireAdmin() {
  const sessionUser = await getSessionUser()
  if (!sessionUser) throw new Error('Unauthorized')
  const [row] = await db.select({ role: user.role }).from(user).where(eq(user.id, sessionUser.id))
  if (row?.role !== 'admin') throw new Error('Forbidden')
  return sessionUser
}

export async function isCurrentUserAdmin() {
  const sessionUser = await getSessionUser()
  if (!sessionUser) return false
  const [row] = await db.select({ role: user.role }).from(user).where(eq(user.id, sessionUser.id))
  return row?.role === 'admin'
}

export async function createReservation(input: {
  name: string
  location: string
  vehicle: string
  start: string
  end: string
}) {
  const name = input.name.trim().slice(0, 120)
  const validVehicle = fleet.some((v) => v.category === input.vehicle)
  const validLocation = (locations as readonly string[]).includes(input.location)

  if (!name || !validVehicle || !validLocation) return { ok: false as const }
  if (!DATE_RE.test(input.start) || !DATE_RE.test(input.end) || input.end <= input.start) {
    return { ok: false as const }
  }

  const sessionUser = await getSessionUser()
  await db.insert(reservations).values({
    userId: sessionUser?.id ?? null,
    name,
    location: input.location,
    vehicle: input.vehicle,
    startDate: input.start,
    endDate: input.end,
  })
  revalidatePath('/admin')
  return { ok: true as const }
}

export async function listReservations() {
  await requireAdmin()
  return db.select().from(reservations).orderBy(desc(reservations.createdAt))
}

export async function updateReservationStatus(id: number, status: ReservationStatus) {
  await requireAdmin()
  if (!Number.isInteger(id) || !STATUSES.includes(status)) throw new Error('Invalid input')
  await db.update(reservations).set({ status }).where(eq(reservations.id, id))
  revalidatePath('/admin')
}

export async function deleteReservation(id: number) {
  await requireAdmin()
  if (!Number.isInteger(id)) throw new Error('Invalid input')
  await db.delete(reservations).where(eq(reservations.id, id))
  revalidatePath('/admin')
}

export async function adminExists() {
  const rows = await db.select({ id: user.id }).from(user).where(eq(user.role, 'admin')).limit(1)
  return rows.length > 0
}

export async function claimFirstAdmin() {
  const sessionUser = await getSessionUser()
  if (!sessionUser) throw new Error('Unauthorized')
  if (await adminExists()) throw new Error('Forbidden')
  await db.update(user).set({ role: 'admin' }).where(eq(user.id, sessionUser.id))
  revalidatePath('/cuenta')
  revalidatePath('/admin')
}
