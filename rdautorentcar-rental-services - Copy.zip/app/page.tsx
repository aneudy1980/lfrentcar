import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { Fleet } from '@/components/fleet'
import { Benefits } from '@/components/benefits'
import { HowItWorks } from '@/components/how-it-works'
import { Faq } from '@/components/faq'
import { ContactCta } from '@/components/contact-cta'
import { SiteFooter } from '@/components/site-footer'

export default function Page() {
  return (
    <>
      <SiteHeader />
      <main>
        <Hero />
        <Fleet />
        <Benefits />
        <HowItWorks />
        <Faq />
        <ContactCta />
      </main>
      <SiteFooter />
    </>
  )
}
