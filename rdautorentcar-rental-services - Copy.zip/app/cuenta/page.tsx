import { headers } from 'next/headers'
import { redirect } from 'next/navigation'
import Link from 'next/link'
import type { Metadata } from 'next'
import { CalendarCheck, Mail, ShieldCheck, UserRound } from 'lucide-react'
import { auth } from '@/lib/auth'
import { adminExists, isCurrentUserAdmin } from '@/app/actions/reservations'
import { ClaimAdminButton } from '@/components/admin/claim-admin-button'
import { SiteHeader } from '@/components/site-header'
import { SignOutButton } from '@/components/sign-out-button'

export const metadata: Metadata = { title: 'Mi cuenta | RD Auto Rent Car' }

export default async function AccountPage() {
  const session = await auth.api.getSession({ headers: await headers() })
  if (!session?.user) redirect('/sign-in')
  const { user } = session
  const isAdmin = await isCurrentUserAdmin()
  const canClaimAdmin = !isAdmin && !(await adminExists())

  return (
    <>
      <SiteHeader />
      <main className="mx-auto max-w-3xl px-4 py-12">
        <h1 className="text-3xl font-bold text-balance">Hola, {user.name}</h1>
        <p className="mt-2 text-muted-foreground">Bienvenido a tu cuenta de RD Auto Rent Car.</p>

        <section aria-labelledby="perfil" className="mt-8 rounded-2xl border border-border bg-card p-6">
          <h2 id="perfil" className="text-lg font-semibold">
            Tu perfil
          </h2>
          <dl className="mt-4 flex flex-col gap-3 text-sm">
            <div className="flex items-center gap-3">
              <UserRound className="size-4 text-primary" aria-hidden="true" />
              <dt className="sr-only">Nombre</dt>
              <dd>{user.name}</dd>
            </div>
            <div className="flex items-center gap-3">
              <Mail className="size-4 text-primary" aria-hidden="true" />
              <dt className="sr-only">Correo</dt>
              <dd>{user.email}</dd>
            </div>
          </dl>
        </section>

        <section className="mt-6 flex flex-col items-start gap-4 rounded-2xl bg-primary p-6 text-primary-foreground sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-center gap-3">
            <CalendarCheck className="size-6" aria-hidden="true" />
            <p className="font-medium">¿Listo para tu próximo viaje?</p>
          </div>
          <Link
            href="/"
            className="rounded-lg bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground hover:opacity-90"
          >
            Reservar un vehículo
          </Link>
        </section>

        {isAdmin ? (
          <section className="mt-6 flex flex-col items-start gap-4 rounded-2xl border border-border bg-card p-6 sm:flex-row sm:items-center sm:justify-between">
            <div className="flex items-center gap-3">
              <ShieldCheck className="size-6 text-primary" aria-hidden="true" />
              <p className="font-medium">Tienes acceso de administrador.</p>
            </div>
            <Link
              href="/admin"
              className="rounded-lg bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:opacity-90"
            >
              Ir al panel
            </Link>
          </section>
        ) : canClaimAdmin ? (
          <section className="mt-6 flex flex-col items-start gap-4 rounded-2xl border border-dashed border-border p-6">
            <p className="text-sm text-muted-foreground">
              Todavía no hay un administrador. Activa tu cuenta como administrador para gestionar las reservas.
            </p>
            <ClaimAdminButton />
          </section>
        ) : null}

        <div className="mt-8">
          <SignOutButton />
        </div>
      </main>
    </>
  )
}
